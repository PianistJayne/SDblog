$(function(){
	$("form").validate({
		rules:{
			userName:{
				required:true
			},
			password:{
				required:true
			},
//			vcode:{
//				required:true
//			}
		},
		messages:{
			userName:{
				required:"管理员用户名不能为空"
			},
			password:{
				required:"请输入管理员密码"
			},
//			vcode:{
//				required:"请输入验证码"
//			}
		},
		submitHandler: function(form) { //通过之后回调
			//进行ajax传值
			$.ajax({
			　　type:"post",
	    		url:"index",
	    		data:{
	    			userName:$("#name").val(),
	    			password:$("#pwd").val()
	    		},
	    		success:function(data){
	    			if (data=="1"){
	    				location.href="/admin/Index/index";
	    			}
	    			else if(data=="2"){
	    				$("#myModalLabel").text("登录失败");
	    				$(".modal-body").text("请重新登录！");
	    				$("#myModal").toggle();
	    				
	    			}
	    		}
			});
		},
		invalidHandler: function(form, validator) {return false;}
	});
});